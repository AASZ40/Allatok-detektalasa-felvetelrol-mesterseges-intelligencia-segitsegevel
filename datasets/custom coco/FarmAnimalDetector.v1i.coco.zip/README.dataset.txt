# FarmAnimalDetector > 2024-04-24 10:23am
https://universe.roboflow.com/asz/farmanimaldetector

Provided by a Roboflow user
License: CC BY 4.0

