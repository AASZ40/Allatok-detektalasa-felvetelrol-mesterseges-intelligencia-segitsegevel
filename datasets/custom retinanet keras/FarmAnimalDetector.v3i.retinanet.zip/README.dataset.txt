# FarmAnimalDetector > 2024-04-24 4:41pm
https://universe.roboflow.com/asz/farmanimaldetector

Provided by a Roboflow user
License: CC BY 4.0

